﻿namespace Plataforma
{
    partial class adminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.estudio = new System.Windows.Forms.TabPage();
            this.editStudioButton = new System.Windows.Forms.Button();
            this.deleteEstudioButton = new System.Windows.Forms.Button();
            this.addEstudioButton = new System.Windows.Forms.Button();
            this.randomEstudio = new System.Windows.Forms.Button();
            this.dateEstudioText = new System.Windows.Forms.TextBox();
            this.localizacaoEstudioText = new System.Windows.Forms.TextBox();
            this.nomeEstudioText = new System.Windows.Forms.TextBox();
            this.estudioIDTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.conteudo = new System.Windows.Forms.TabPage();
            this.premiosConteudoCheckBox = new System.Windows.Forms.CheckedListBox();
            this.genresConteudoCheckBox = new System.Windows.Forms.CheckedListBox();
            this.nameestudioConteudoCombo = new System.Windows.Forms.ComboBox();
            this.generoslabel = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.ratingConteudoText = new System.Windows.Forms.TextBox();
            this.ratingConteudoLabel = new System.Windows.Forms.Label();
            this.dateConteudoText = new System.Windows.Forms.TextBox();
            this.runtimeConteudoText = new System.Windows.Forms.TextBox();
            this.runtimeConteudoLabel = new System.Windows.Forms.Label();
            this.dateConteudoLabel = new System.Windows.Forms.Label();
            this.tipoConteudoCombo = new System.Windows.Forms.ComboBox();
            this.Synopsis = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.addConteudoButton = new System.Windows.Forms.Button();
            this.randomConteudoButton = new System.Windows.Forms.Button();
            this.synopsisConteudoText = new System.Windows.Forms.TextBox();
            this.nomeConteudoText = new System.Windows.Forms.TextBox();
            this.idConteudoText = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.temporada = new System.Windows.Forms.TabPage();
            this.num_seasonSeasonText = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.randomTemporadaButton = new System.Windows.Forms.Button();
            this.id_seasonSeasonText = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.name_contentSeasonLabel = new System.Windows.Forms.Label();
            this.id_contentSeasonCombo = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.addSeasonButton = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.episodio = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.ratingEpisodioText = new System.Windows.Forms.TextBox();
            this.name_contentEpisodioLabel = new System.Windows.Forms.Label();
            this.id_seasonEpisodioCombo = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.dataEpisodioText = new System.Windows.Forms.TextBox();
            this.runtimeEpisodioText = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.addEpisodio = new System.Windows.Forms.Button();
            this.synopsisEpisodioText = new System.Windows.Forms.TextBox();
            this.num_episodioEpisodioText = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.contentids = new System.Windows.Forms.TabPage();
            this.comboBoxContent = new System.Windows.Forms.ComboBox();
            this.Content_id = new System.Windows.Forms.Label();
            this.randomidPessoa = new System.Windows.Forms.Button();
            this.id_atorPessoaText = new System.Windows.Forms.TextBox();
            this.id_atorPessoaLabel = new System.Windows.Forms.Label();
            this.datePessoaText = new System.Windows.Forms.TextBox();
            this.numFIlmesPessoaText = new System.Windows.Forms.TextBox();
            this.tipoPessoaCombo = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.addPessoa = new System.Windows.Forms.Button();
            this.randomCCPessoa = new System.Windows.Forms.Button();
            this.nomePessoaText = new System.Windows.Forms.TextBox();
            this.numCCPessoaText = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.personagem = new System.Windows.Forms.TabPage();
            this.papelPersonagemCombo = new System.Windows.Forms.ComboBox();
            this.nextPersonagemId = new System.Windows.Forms.Button();
            this.id_personagemPersonagemText = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.name_contentPersonagemLabel = new System.Windows.Forms.Label();
            this.id_contentPersonagemCombo = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.name_atorPersonagemLabel = new System.Windows.Forms.Label();
            this.ator_idPersonagemCombo = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.addPersonagem = new System.Windows.Forms.Button();
            this.nomePersonagemText = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.user = new System.Windows.Forms.TabPage();
            this.passwordUserText = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.nomeUserText = new System.Windows.Forms.TextBox();
            this.randomUser = new System.Windows.Forms.Button();
            this.idUserText = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.addUser = new System.Windows.Forms.Button();
            this.label49 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.listBox7 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.estudio.SuspendLayout();
            this.conteudo.SuspendLayout();
            this.temporada.SuspendLayout();
            this.episodio.SuspendLayout();
            this.contentids.SuspendLayout();
            this.personagem.SuspendLayout();
            this.user.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.estudio);
            this.tabControl1.Controls.Add(this.conteudo);
            this.tabControl1.Controls.Add(this.temporada);
            this.tabControl1.Controls.Add(this.episodio);
            this.tabControl1.Controls.Add(this.contentids);
            this.tabControl1.Controls.Add(this.personagem);
            this.tabControl1.Controls.Add(this.user);
            this.tabControl1.Location = new System.Drawing.Point(0, 35);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(920, 571);
            this.tabControl1.TabIndex = 0;
            // 
            // estudio
            // 
            this.estudio.Controls.Add(this.editStudioButton);
            this.estudio.Controls.Add(this.deleteEstudioButton);
            this.estudio.Controls.Add(this.addEstudioButton);
            this.estudio.Controls.Add(this.randomEstudio);
            this.estudio.Controls.Add(this.dateEstudioText);
            this.estudio.Controls.Add(this.localizacaoEstudioText);
            this.estudio.Controls.Add(this.nomeEstudioText);
            this.estudio.Controls.Add(this.estudioIDTextBox);
            this.estudio.Controls.Add(this.label6);
            this.estudio.Controls.Add(this.label9);
            this.estudio.Controls.Add(this.label5);
            this.estudio.Controls.Add(this.label4);
            this.estudio.Controls.Add(this.label3);
            this.estudio.Controls.Add(this.label2);
            this.estudio.Controls.Add(this.listBox1);
            this.estudio.Location = new System.Drawing.Point(4, 29);
            this.estudio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.estudio.Name = "estudio";
            this.estudio.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.estudio.Size = new System.Drawing.Size(912, 538);
            this.estudio.TabIndex = 0;
            this.estudio.Text = "Estudio";
            this.estudio.UseVisualStyleBackColor = true;
            // 
            // editStudioButton
            // 
            this.editStudioButton.Location = new System.Drawing.Point(718, 373);
            this.editStudioButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.editStudioButton.Name = "editStudioButton";
            this.editStudioButton.Size = new System.Drawing.Size(120, 73);
            this.editStudioButton.TabIndex = 31;
            this.editStudioButton.Text = "Edit";
            this.editStudioButton.UseVisualStyleBackColor = true;
            this.editStudioButton.Click += new System.EventHandler(this.editStudioButton_Click);
            // 
            // deleteEstudioButton
            // 
            this.deleteEstudioButton.Location = new System.Drawing.Point(563, 373);
            this.deleteEstudioButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.deleteEstudioButton.Name = "deleteEstudioButton";
            this.deleteEstudioButton.Size = new System.Drawing.Size(120, 73);
            this.deleteEstudioButton.TabIndex = 30;
            this.deleteEstudioButton.Text = "Delete";
            this.deleteEstudioButton.UseVisualStyleBackColor = true;
            this.deleteEstudioButton.Click += new System.EventHandler(this.deleteEstudioButton_Click);
            // 
            // addEstudioButton
            // 
            this.addEstudioButton.Location = new System.Drawing.Point(406, 373);
            this.addEstudioButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEstudioButton.Name = "addEstudioButton";
            this.addEstudioButton.Size = new System.Drawing.Size(120, 73);
            this.addEstudioButton.TabIndex = 29;
            this.addEstudioButton.Text = "Add";
            this.addEstudioButton.UseVisualStyleBackColor = true;
            this.addEstudioButton.Click += new System.EventHandler(this.addEstudioButton_Click_1);
            // 
            // randomEstudio
            // 
            this.randomEstudio.Location = new System.Drawing.Point(647, 49);
            this.randomEstudio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.randomEstudio.Name = "randomEstudio";
            this.randomEstudio.Size = new System.Drawing.Size(86, 31);
            this.randomEstudio.TabIndex = 28;
            this.randomEstudio.Text = "NextIdEstudio";
            this.randomEstudio.UseVisualStyleBackColor = true;
            this.randomEstudio.Click += new System.EventHandler(this.randomEstudio_Click_1);
            // 
            // dateEstudioText
            // 
            this.dateEstudioText.Location = new System.Drawing.Point(498, 228);
            this.dateEstudioText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateEstudioText.Name = "dateEstudioText";
            this.dateEstudioText.Size = new System.Drawing.Size(114, 27);
            this.dateEstudioText.TabIndex = 27;
            // 
            // localizacaoEstudioText
            // 
            this.localizacaoEstudioText.Location = new System.Drawing.Point(498, 173);
            this.localizacaoEstudioText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.localizacaoEstudioText.Name = "localizacaoEstudioText";
            this.localizacaoEstudioText.Size = new System.Drawing.Size(114, 27);
            this.localizacaoEstudioText.TabIndex = 26;
            // 
            // nomeEstudioText
            // 
            this.nomeEstudioText.Location = new System.Drawing.Point(498, 108);
            this.nomeEstudioText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nomeEstudioText.Name = "nomeEstudioText";
            this.nomeEstudioText.Size = new System.Drawing.Size(114, 27);
            this.nomeEstudioText.TabIndex = 25;
            // 
            // estudioIDTextBox
            // 
            this.estudioIDTextBox.Location = new System.Drawing.Point(498, 49);
            this.estudioIDTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.estudioIDTextBox.Name = "estudioIDTextBox";
            this.estudioIDTextBox.Size = new System.Drawing.Size(114, 27);
            this.estudioIDTextBox.TabIndex = 24;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(383, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 20);
            this.label6.TabIndex = 23;
            this.label6.Text = "Estudio_ID";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(350, -55);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(13, 640);
            this.label9.TabIndex = 22;
            this.label9.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n" +
    "|\r\n|\r\n|\r\n|\r\n|\r\n";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(383, 232);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Ana de Criacao:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(383, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Localizacao";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(383, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lista de Estudios:";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(0, 28);
            this.listBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(344, 504);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // conteudo
            // 
            this.conteudo.Controls.Add(this.premiosConteudoCheckBox);
            this.conteudo.Controls.Add(this.genresConteudoCheckBox);
            this.conteudo.Controls.Add(this.nameestudioConteudoCombo);
            this.conteudo.Controls.Add(this.generoslabel);
            this.conteudo.Controls.Add(this.label15);
            this.conteudo.Controls.Add(this.ratingConteudoText);
            this.conteudo.Controls.Add(this.ratingConteudoLabel);
            this.conteudo.Controls.Add(this.dateConteudoText);
            this.conteudo.Controls.Add(this.runtimeConteudoText);
            this.conteudo.Controls.Add(this.runtimeConteudoLabel);
            this.conteudo.Controls.Add(this.dateConteudoLabel);
            this.conteudo.Controls.Add(this.tipoConteudoCombo);
            this.conteudo.Controls.Add(this.Synopsis);
            this.conteudo.Controls.Add(this.button5);
            this.conteudo.Controls.Add(this.button6);
            this.conteudo.Controls.Add(this.addConteudoButton);
            this.conteudo.Controls.Add(this.randomConteudoButton);
            this.conteudo.Controls.Add(this.synopsisConteudoText);
            this.conteudo.Controls.Add(this.nomeConteudoText);
            this.conteudo.Controls.Add(this.idConteudoText);
            this.conteudo.Controls.Add(this.label7);
            this.conteudo.Controls.Add(this.label8);
            this.conteudo.Controls.Add(this.label10);
            this.conteudo.Controls.Add(this.label11);
            this.conteudo.Controls.Add(this.label12);
            this.conteudo.Controls.Add(this.label13);
            this.conteudo.Controls.Add(this.listBox2);
            this.conteudo.Location = new System.Drawing.Point(4, 29);
            this.conteudo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.conteudo.Name = "conteudo";
            this.conteudo.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.conteudo.Size = new System.Drawing.Size(912, 538);
            this.conteudo.TabIndex = 1;
            this.conteudo.Text = "Conteudo";
            this.conteudo.UseVisualStyleBackColor = true;
            // 
            // premiosConteudoCheckBox
            // 
            this.premiosConteudoCheckBox.FormattingEnabled = true;
            this.premiosConteudoCheckBox.Location = new System.Drawing.Point(709, 261);
            this.premiosConteudoCheckBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.premiosConteudoCheckBox.Name = "premiosConteudoCheckBox";
            this.premiosConteudoCheckBox.Size = new System.Drawing.Size(147, 114);
            this.premiosConteudoCheckBox.TabIndex = 64;
            // 
            // genresConteudoCheckBox
            // 
            this.genresConteudoCheckBox.FormattingEnabled = true;
            this.genresConteudoCheckBox.Location = new System.Drawing.Point(709, 103);
            this.genresConteudoCheckBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.genresConteudoCheckBox.Name = "genresConteudoCheckBox";
            this.genresConteudoCheckBox.Size = new System.Drawing.Size(147, 114);
            this.genresConteudoCheckBox.TabIndex = 63;
            // 
            // nameestudioConteudoCombo
            // 
            this.nameestudioConteudoCombo.FormattingEnabled = true;
            this.nameestudioConteudoCombo.Location = new System.Drawing.Point(493, 112);
            this.nameestudioConteudoCombo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nameestudioConteudoCombo.Name = "nameestudioConteudoCombo";
            this.nameestudioConteudoCombo.Size = new System.Drawing.Size(186, 28);
            this.nameestudioConteudoCombo.TabIndex = 62;
            // 
            // generoslabel
            // 
            this.generoslabel.AutoSize = true;
            this.generoslabel.Location = new System.Drawing.Point(709, 67);
            this.generoslabel.Name = "generoslabel";
            this.generoslabel.Size = new System.Drawing.Size(57, 20);
            this.generoslabel.TabIndex = 60;
            this.generoslabel.Text = "Genero";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(709, 237);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 20);
            this.label15.TabIndex = 58;
            this.label15.Text = "Premio";
            // 
            // ratingConteudoText
            // 
            this.ratingConteudoText.Location = new System.Drawing.Point(493, 385);
            this.ratingConteudoText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ratingConteudoText.Name = "ratingConteudoText";
            this.ratingConteudoText.Size = new System.Drawing.Size(186, 27);
            this.ratingConteudoText.TabIndex = 57;
            this.ratingConteudoText.Visible = false;
            // 
            // ratingConteudoLabel
            // 
            this.ratingConteudoLabel.AutoSize = true;
            this.ratingConteudoLabel.Location = new System.Drawing.Point(377, 389);
            this.ratingConteudoLabel.Name = "ratingConteudoLabel";
            this.ratingConteudoLabel.Size = new System.Drawing.Size(52, 20);
            this.ratingConteudoLabel.TabIndex = 56;
            this.ratingConteudoLabel.Text = "Rating";
            this.ratingConteudoLabel.Visible = false;
            // 
            // dateConteudoText
            // 
            this.dateConteudoText.Location = new System.Drawing.Point(493, 333);
            this.dateConteudoText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateConteudoText.Name = "dateConteudoText";
            this.dateConteudoText.Size = new System.Drawing.Size(186, 27);
            this.dateConteudoText.TabIndex = 54;
            this.dateConteudoText.Visible = false;
            // 
            // runtimeConteudoText
            // 
            this.runtimeConteudoText.Location = new System.Drawing.Point(493, 275);
            this.runtimeConteudoText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.runtimeConteudoText.Name = "runtimeConteudoText";
            this.runtimeConteudoText.Size = new System.Drawing.Size(186, 27);
            this.runtimeConteudoText.TabIndex = 53;
            this.runtimeConteudoText.Visible = false;
            this.runtimeConteudoText.TextChanged += new System.EventHandler(this.runtimeConteudoText_TextChanged);
            // 
            // runtimeConteudoLabel
            // 
            this.runtimeConteudoLabel.AutoSize = true;
            this.runtimeConteudoLabel.Location = new System.Drawing.Point(377, 279);
            this.runtimeConteudoLabel.Name = "runtimeConteudoLabel";
            this.runtimeConteudoLabel.Size = new System.Drawing.Size(64, 20);
            this.runtimeConteudoLabel.TabIndex = 52;
            this.runtimeConteudoLabel.Text = "Runtime";
            this.runtimeConteudoLabel.Visible = false;
            // 
            // dateConteudoLabel
            // 
            this.dateConteudoLabel.AutoSize = true;
            this.dateConteudoLabel.Location = new System.Drawing.Point(377, 337);
            this.dateConteudoLabel.Name = "dateConteudoLabel";
            this.dateConteudoLabel.Size = new System.Drawing.Size(110, 20);
            this.dateConteudoLabel.TabIndex = 51;
            this.dateConteudoLabel.Text = "Data de Estreia";
            this.dateConteudoLabel.Visible = false;
            // 
            // tipoConteudoCombo
            // 
            this.tipoConteudoCombo.FormattingEnabled = true;
            this.tipoConteudoCombo.Items.AddRange(new object[] {
            "Filme",
            "Série"});
            this.tipoConteudoCombo.Location = new System.Drawing.Point(493, 215);
            this.tipoConteudoCombo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tipoConteudoCombo.Name = "tipoConteudoCombo";
            this.tipoConteudoCombo.Size = new System.Drawing.Size(186, 28);
            this.tipoConteudoCombo.TabIndex = 50;
            this.tipoConteudoCombo.SelectedIndexChanged += new System.EventHandler(this.tipoConteudoCombo_SelectedIndexChanged_1);
            // 
            // Synopsis
            // 
            this.Synopsis.AutoSize = true;
            this.Synopsis.Location = new System.Drawing.Point(377, 219);
            this.Synopsis.Name = "Synopsis";
            this.Synopsis.Size = new System.Drawing.Size(39, 20);
            this.Synopsis.TabIndex = 48;
            this.Synopsis.Text = "Tipo";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(619, 463);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(120, 40);
            this.button5.TabIndex = 46;
            this.button5.Text = "Edit";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(493, 463);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(120, 40);
            this.button6.TabIndex = 45;
            this.button6.Text = "Delete";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // addConteudoButton
            // 
            this.addConteudoButton.Location = new System.Drawing.Point(363, 463);
            this.addConteudoButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addConteudoButton.Name = "addConteudoButton";
            this.addConteudoButton.Size = new System.Drawing.Size(120, 40);
            this.addConteudoButton.TabIndex = 44;
            this.addConteudoButton.Text = "Add";
            this.addConteudoButton.UseVisualStyleBackColor = true;
            this.addConteudoButton.Click += new System.EventHandler(this.addConteudoButton_Click_1);
            // 
            // randomConteudoButton
            // 
            this.randomConteudoButton.Location = new System.Drawing.Point(709, 12);
            this.randomConteudoButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.randomConteudoButton.Name = "randomConteudoButton";
            this.randomConteudoButton.Size = new System.Drawing.Size(137, 31);
            this.randomConteudoButton.TabIndex = 43;
            this.randomConteudoButton.Text = "NextIdContent";
            this.randomConteudoButton.UseVisualStyleBackColor = true;
            this.randomConteudoButton.Click += new System.EventHandler(this.randomConteudoButton_Click_1);
            // 
            // synopsisConteudoText
            // 
            this.synopsisConteudoText.Location = new System.Drawing.Point(493, 163);
            this.synopsisConteudoText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.synopsisConteudoText.Name = "synopsisConteudoText";
            this.synopsisConteudoText.Size = new System.Drawing.Size(186, 27);
            this.synopsisConteudoText.TabIndex = 42;
            // 
            // nomeConteudoText
            // 
            this.nomeConteudoText.Location = new System.Drawing.Point(493, 63);
            this.nomeConteudoText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nomeConteudoText.Name = "nomeConteudoText";
            this.nomeConteudoText.Size = new System.Drawing.Size(186, 27);
            this.nomeConteudoText.TabIndex = 40;
            // 
            // idConteudoText
            // 
            this.idConteudoText.Location = new System.Drawing.Point(493, 12);
            this.idConteudoText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.idConteudoText.Name = "idConteudoText";
            this.idConteudoText.Size = new System.Drawing.Size(186, 27);
            this.idConteudoText.TabIndex = 39;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(377, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 20);
            this.label7.TabIndex = 38;
            this.label7.Text = "Content_ID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(345, -55);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(13, 640);
            this.label8.TabIndex = 37;
            this.label8.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n" +
    "|\r\n|\r\n|\r\n|\r\n|\r\n";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(377, 167);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 20);
            this.label10.TabIndex = 36;
            this.label10.Text = "Synopsis:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(377, 123);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 20);
            this.label11.TabIndex = 35;
            this.label11.Text = "Estudio_Name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(377, 67);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 20);
            this.label12.TabIndex = 34;
            this.label12.Text = "Nome";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(-1, 4);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(129, 20);
            this.label13.TabIndex = 33;
            this.label13.Text = "Lista de Conteudo";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 20;
            this.listBox2.Location = new System.Drawing.Point(-5, 28);
            this.listBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(329, 504);
            this.listBox2.TabIndex = 32;
            // 
            // temporada
            // 
            this.temporada.Controls.Add(this.num_seasonSeasonText);
            this.temporada.Controls.Add(this.label53);
            this.temporada.Controls.Add(this.randomTemporadaButton);
            this.temporada.Controls.Add(this.id_seasonSeasonText);
            this.temporada.Controls.Add(this.label42);
            this.temporada.Controls.Add(this.name_contentSeasonLabel);
            this.temporada.Controls.Add(this.id_contentSeasonCombo);
            this.temporada.Controls.Add(this.label44);
            this.temporada.Controls.Add(this.button22);
            this.temporada.Controls.Add(this.button23);
            this.temporada.Controls.Add(this.addSeasonButton);
            this.temporada.Controls.Add(this.label47);
            this.temporada.Controls.Add(this.label50);
            this.temporada.Controls.Add(this.listBox6);
            this.temporada.Location = new System.Drawing.Point(4, 29);
            this.temporada.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.temporada.Name = "temporada";
            this.temporada.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.temporada.Size = new System.Drawing.Size(912, 538);
            this.temporada.TabIndex = 6;
            this.temporada.Text = "Temporada";
            this.temporada.UseVisualStyleBackColor = true;
            // 
            // num_seasonSeasonText
            // 
            this.num_seasonSeasonText.Location = new System.Drawing.Point(498, 137);
            this.num_seasonSeasonText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.num_seasonSeasonText.Name = "num_seasonSeasonText";
            this.num_seasonSeasonText.Size = new System.Drawing.Size(186, 27);
            this.num_seasonSeasonText.TabIndex = 124;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(383, 143);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(94, 20);
            this.label53.TabIndex = 123;
            this.label53.Text = "Season_Num";
            // 
            // randomTemporadaButton
            // 
            this.randomTemporadaButton.Location = new System.Drawing.Point(714, 33);
            this.randomTemporadaButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.randomTemporadaButton.Name = "randomTemporadaButton";
            this.randomTemporadaButton.Size = new System.Drawing.Size(145, 31);
            this.randomTemporadaButton.TabIndex = 122;
            this.randomTemporadaButton.Text = "NextIdTemporada";
            this.randomTemporadaButton.UseVisualStyleBackColor = true;
            this.randomTemporadaButton.Click += new System.EventHandler(this.randomTemporadaButton_Click_1);
            // 
            // id_seasonSeasonText
            // 
            this.id_seasonSeasonText.Location = new System.Drawing.Point(498, 33);
            this.id_seasonSeasonText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.id_seasonSeasonText.Name = "id_seasonSeasonText";
            this.id_seasonSeasonText.Size = new System.Drawing.Size(186, 27);
            this.id_seasonSeasonText.TabIndex = 121;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(383, 39);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(77, 20);
            this.label42.TabIndex = 120;
            this.label42.Text = "Season_ID";
            // 
            // name_contentSeasonLabel
            // 
            this.name_contentSeasonLabel.AutoSize = true;
            this.name_contentSeasonLabel.Location = new System.Drawing.Point(706, 92);
            this.name_contentSeasonLabel.Name = "name_contentSeasonLabel";
            this.name_contentSeasonLabel.Size = new System.Drawing.Size(107, 20);
            this.name_contentSeasonLabel.TabIndex = 119;
            this.name_contentSeasonLabel.Text = "Content_Name";
            // 
            // id_contentSeasonCombo
            // 
            this.id_contentSeasonCombo.FormattingEnabled = true;
            this.id_contentSeasonCombo.Location = new System.Drawing.Point(499, 92);
            this.id_contentSeasonCombo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.id_contentSeasonCombo.Name = "id_contentSeasonCombo";
            this.id_contentSeasonCombo.Size = new System.Drawing.Size(186, 28);
            this.id_contentSeasonCombo.TabIndex = 118;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(383, 92);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(82, 20);
            this.label44.TabIndex = 117;
            this.label44.Text = "Content_ID";
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(739, 452);
            this.button22.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(120, 56);
            this.button22.TabIndex = 113;
            this.button22.Text = "Edit";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(565, 452);
            this.button23.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(120, 56);
            this.button23.TabIndex = 112;
            this.button23.Text = "Delete";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // addSeasonButton
            // 
            this.addSeasonButton.Location = new System.Drawing.Point(400, 452);
            this.addSeasonButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addSeasonButton.Name = "addSeasonButton";
            this.addSeasonButton.Size = new System.Drawing.Size(120, 56);
            this.addSeasonButton.TabIndex = 111;
            this.addSeasonButton.Text = "Add";
            this.addSeasonButton.UseVisualStyleBackColor = true;
            this.addSeasonButton.Click += new System.EventHandler(this.addSeasonButton_Click_1);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(350, -49);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(13, 640);
            this.label47.TabIndex = 108;
            this.label47.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n" +
    "|\r\n|\r\n|\r\n|\r\n|\r\n";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(3, 9);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(119, 20);
            this.label50.TabIndex = 105;
            this.label50.Text = "Lista Temporada";
            // 
            // listBox6
            // 
            this.listBox6.FormattingEnabled = true;
            this.listBox6.ItemHeight = 20;
            this.listBox6.Location = new System.Drawing.Point(0, 33);
            this.listBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(329, 504);
            this.listBox6.TabIndex = 104;
            // 
            // episodio
            // 
            this.episodio.Controls.Add(this.button1);
            this.episodio.Controls.Add(this.ratingEpisodioText);
            this.episodio.Controls.Add(this.name_contentEpisodioLabel);
            this.episodio.Controls.Add(this.id_seasonEpisodioCombo);
            this.episodio.Controls.Add(this.label26);
            this.episodio.Controls.Add(this.dataEpisodioText);
            this.episodio.Controls.Add(this.runtimeEpisodioText);
            this.episodio.Controls.Add(this.label16);
            this.episodio.Controls.Add(this.label25);
            this.episodio.Controls.Add(this.button14);
            this.episodio.Controls.Add(this.button15);
            this.episodio.Controls.Add(this.addEpisodio);
            this.episodio.Controls.Add(this.synopsisEpisodioText);
            this.episodio.Controls.Add(this.num_episodioEpisodioText);
            this.episodio.Controls.Add(this.label27);
            this.episodio.Controls.Add(this.label28);
            this.episodio.Controls.Add(this.label29);
            this.episodio.Controls.Add(this.label32);
            this.episodio.Controls.Add(this.label31);
            this.episodio.Controls.Add(this.listBox4);
            this.episodio.Location = new System.Drawing.Point(4, 29);
            this.episodio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.episodio.Name = "episodio";
            this.episodio.Size = new System.Drawing.Size(912, 538);
            this.episodio.TabIndex = 4;
            this.episodio.Text = "Episodio";
            this.episodio.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(706, 89);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(144, 29);
            this.button1.TabIndex = 81;
            this.button1.Text = "nextEpisodeNum";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ratingEpisodioText
            // 
            this.ratingEpisodioText.Location = new System.Drawing.Point(498, 336);
            this.ratingEpisodioText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ratingEpisodioText.Name = "ratingEpisodioText";
            this.ratingEpisodioText.Size = new System.Drawing.Size(186, 27);
            this.ratingEpisodioText.TabIndex = 80;
            // 
            // name_contentEpisodioLabel
            // 
            this.name_contentEpisodioLabel.AutoSize = true;
            this.name_contentEpisodioLabel.Location = new System.Drawing.Point(706, 39);
            this.name_contentEpisodioLabel.Name = "name_contentEpisodioLabel";
            this.name_contentEpisodioLabel.Size = new System.Drawing.Size(107, 20);
            this.name_contentEpisodioLabel.TabIndex = 78;
            this.name_contentEpisodioLabel.Text = "Content_Name";
            // 
            // id_seasonEpisodioCombo
            // 
            this.id_seasonEpisodioCombo.FormattingEnabled = true;
            this.id_seasonEpisodioCombo.Location = new System.Drawing.Point(498, 35);
            this.id_seasonEpisodioCombo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.id_seasonEpisodioCombo.Name = "id_seasonEpisodioCombo";
            this.id_seasonEpisodioCombo.Size = new System.Drawing.Size(186, 28);
            this.id_seasonEpisodioCombo.TabIndex = 77;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(383, 39);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(77, 20);
            this.label26.TabIndex = 76;
            this.label26.Text = "Season_ID";
            // 
            // dataEpisodioText
            // 
            this.dataEpisodioText.Location = new System.Drawing.Point(498, 275);
            this.dataEpisodioText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataEpisodioText.Name = "dataEpisodioText";
            this.dataEpisodioText.Size = new System.Drawing.Size(186, 27);
            this.dataEpisodioText.TabIndex = 75;
            // 
            // runtimeEpisodioText
            // 
            this.runtimeEpisodioText.Location = new System.Drawing.Point(498, 216);
            this.runtimeEpisodioText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.runtimeEpisodioText.Name = "runtimeEpisodioText";
            this.runtimeEpisodioText.Size = new System.Drawing.Size(186, 27);
            this.runtimeEpisodioText.TabIndex = 74;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(383, 220);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 20);
            this.label16.TabIndex = 73;
            this.label16.Text = "Runtime";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(383, 279);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(110, 20);
            this.label25.TabIndex = 72;
            this.label25.Text = "Data de Estreia";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(739, 447);
            this.button14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(120, 56);
            this.button14.TabIndex = 68;
            this.button14.Text = "Edit";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(565, 447);
            this.button15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(120, 56);
            this.button15.TabIndex = 67;
            this.button15.Text = "Delete";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // addEpisodio
            // 
            this.addEpisodio.Location = new System.Drawing.Point(400, 447);
            this.addEpisodio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addEpisodio.Name = "addEpisodio";
            this.addEpisodio.Size = new System.Drawing.Size(120, 56);
            this.addEpisodio.TabIndex = 66;
            this.addEpisodio.Text = "Add";
            this.addEpisodio.UseVisualStyleBackColor = true;
            this.addEpisodio.Click += new System.EventHandler(this.addEpisodio_Click_1);
            // 
            // synopsisEpisodioText
            // 
            this.synopsisEpisodioText.Location = new System.Drawing.Point(498, 151);
            this.synopsisEpisodioText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.synopsisEpisodioText.Name = "synopsisEpisodioText";
            this.synopsisEpisodioText.Size = new System.Drawing.Size(186, 27);
            this.synopsisEpisodioText.TabIndex = 64;
            // 
            // num_episodioEpisodioText
            // 
            this.num_episodioEpisodioText.Location = new System.Drawing.Point(498, 91);
            this.num_episodioEpisodioText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.num_episodioEpisodioText.Name = "num_episodioEpisodioText";
            this.num_episodioEpisodioText.Size = new System.Drawing.Size(186, 27);
            this.num_episodioEpisodioText.TabIndex = 62;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(383, 95);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(102, 20);
            this.label27.TabIndex = 61;
            this.label27.Text = "num_episodio";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(350, -55);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(13, 640);
            this.label28.TabIndex = 60;
            this.label28.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n" +
    "|\r\n|\r\n|\r\n|\r\n|\r\n";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(383, 155);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(69, 20);
            this.label29.TabIndex = 59;
            this.label29.Text = "Synopsis:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(3, 4);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(101, 20);
            this.label32.TabIndex = 56;
            this.label32.Text = "Lista Episodio";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(383, 339);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(52, 20);
            this.label31.TabIndex = 79;
            this.label31.Text = "Rating";
            // 
            // listBox4
            // 
            this.listBox4.FormattingEnabled = true;
            this.listBox4.ItemHeight = 20;
            this.listBox4.Location = new System.Drawing.Point(0, 28);
            this.listBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(329, 504);
            this.listBox4.TabIndex = 55;
            // 
            // contentids
            // 
            this.contentids.Controls.Add(this.comboBoxContent);
            this.contentids.Controls.Add(this.Content_id);
            this.contentids.Controls.Add(this.randomidPessoa);
            this.contentids.Controls.Add(this.id_atorPessoaText);
            this.contentids.Controls.Add(this.id_atorPessoaLabel);
            this.contentids.Controls.Add(this.datePessoaText);
            this.contentids.Controls.Add(this.numFIlmesPessoaText);
            this.contentids.Controls.Add(this.tipoPessoaCombo);
            this.contentids.Controls.Add(this.label18);
            this.contentids.Controls.Add(this.button9);
            this.contentids.Controls.Add(this.button10);
            this.contentids.Controls.Add(this.addPessoa);
            this.contentids.Controls.Add(this.randomCCPessoa);
            this.contentids.Controls.Add(this.nomePessoaText);
            this.contentids.Controls.Add(this.numCCPessoaText);
            this.contentids.Controls.Add(this.label19);
            this.contentids.Controls.Add(this.label20);
            this.contentids.Controls.Add(this.label22);
            this.contentids.Controls.Add(this.label23);
            this.contentids.Controls.Add(this.label24);
            this.contentids.Controls.Add(this.listBox3);
            this.contentids.Location = new System.Drawing.Point(4, 29);
            this.contentids.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.contentids.Name = "contentids";
            this.contentids.Size = new System.Drawing.Size(912, 538);
            this.contentids.TabIndex = 3;
            this.contentids.Text = "Pessoa";
            this.contentids.UseVisualStyleBackColor = true;
            // 
            // comboBoxContent
            // 
            this.comboBoxContent.FormattingEnabled = true;
            this.comboBoxContent.Items.AddRange(new object[] {
            "Ator",
            "Diretor ou Realizador"});
            this.comboBoxContent.Location = new System.Drawing.Point(512, 335);
            this.comboBoxContent.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBoxContent.Name = "comboBoxContent";
            this.comboBoxContent.Size = new System.Drawing.Size(186, 28);
            this.comboBoxContent.TabIndex = 82;
            // 
            // Content_id
            // 
            this.Content_id.AutoSize = true;
            this.Content_id.Location = new System.Drawing.Point(386, 338);
            this.Content_id.Name = "Content_id";
            this.Content_id.Size = new System.Drawing.Size(80, 20);
            this.Content_id.TabIndex = 81;
            this.Content_id.Text = "Content_id";
            // 
            // randomidPessoa
            // 
            this.randomidPessoa.Location = new System.Drawing.Point(728, 285);
            this.randomidPessoa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.randomidPessoa.Name = "randomidPessoa";
            this.randomidPessoa.Size = new System.Drawing.Size(127, 31);
            this.randomidPessoa.TabIndex = 79;
            this.randomidPessoa.Text = "NextIdAtor";
            this.randomidPessoa.UseVisualStyleBackColor = true;
            this.randomidPessoa.Visible = false;
            this.randomidPessoa.Click += new System.EventHandler(this.randomidPessoa_Click_1);
            // 
            // id_atorPessoaText
            // 
            this.id_atorPessoaText.Location = new System.Drawing.Point(512, 285);
            this.id_atorPessoaText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.id_atorPessoaText.Name = "id_atorPessoaText";
            this.id_atorPessoaText.Size = new System.Drawing.Size(186, 27);
            this.id_atorPessoaText.TabIndex = 78;
            this.id_atorPessoaText.Visible = false;
            // 
            // id_atorPessoaLabel
            // 
            this.id_atorPessoaLabel.AutoSize = true;
            this.id_atorPessoaLabel.Location = new System.Drawing.Point(378, 289);
            this.id_atorPessoaLabel.Name = "id_atorPessoaLabel";
            this.id_atorPessoaLabel.Size = new System.Drawing.Size(59, 20);
            this.id_atorPessoaLabel.TabIndex = 77;
            this.id_atorPessoaLabel.Text = "Ator_ID";
            this.id_atorPessoaLabel.Visible = false;
            // 
            // datePessoaText
            // 
            this.datePessoaText.Location = new System.Drawing.Point(512, 157);
            this.datePessoaText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.datePessoaText.Name = "datePessoaText";
            this.datePessoaText.Size = new System.Drawing.Size(186, 27);
            this.datePessoaText.TabIndex = 76;
            // 
            // numFIlmesPessoaText
            // 
            this.numFIlmesPessoaText.Location = new System.Drawing.Point(512, 285);
            this.numFIlmesPessoaText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numFIlmesPessoaText.Name = "numFIlmesPessoaText";
            this.numFIlmesPessoaText.Size = new System.Drawing.Size(186, 27);
            this.numFIlmesPessoaText.TabIndex = 75;
            this.numFIlmesPessoaText.Visible = false;
            // 
            // tipoPessoaCombo
            // 
            this.tipoPessoaCombo.FormattingEnabled = true;
            this.tipoPessoaCombo.Items.AddRange(new object[] {
            "Ator",
            "Diretor ou Realizador"});
            this.tipoPessoaCombo.Location = new System.Drawing.Point(512, 221);
            this.tipoPessoaCombo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tipoPessoaCombo.Name = "tipoPessoaCombo";
            this.tipoPessoaCombo.Size = new System.Drawing.Size(186, 28);
            this.tipoPessoaCombo.TabIndex = 71;
            this.tipoPessoaCombo.SelectedIndexChanged += new System.EventHandler(this.tipoPessoaCombo_SelectedIndexChanged_1);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(378, 225);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(39, 20);
            this.label18.TabIndex = 70;
            this.label18.Text = "Tipo";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(735, 447);
            this.button9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(120, 56);
            this.button9.TabIndex = 68;
            this.button9.Text = "Edit";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(560, 447);
            this.button10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(120, 56);
            this.button10.TabIndex = 67;
            this.button10.Text = "Delete";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // addPessoa
            // 
            this.addPessoa.Location = new System.Drawing.Point(395, 447);
            this.addPessoa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPessoa.Name = "addPessoa";
            this.addPessoa.Size = new System.Drawing.Size(120, 56);
            this.addPessoa.TabIndex = 66;
            this.addPessoa.Text = "Add";
            this.addPessoa.UseVisualStyleBackColor = true;
            this.addPessoa.Click += new System.EventHandler(this.addPessoa_Click_1);
            // 
            // randomCCPessoa
            // 
            this.randomCCPessoa.Location = new System.Drawing.Point(728, 33);
            this.randomCCPessoa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.randomCCPessoa.Name = "randomCCPessoa";
            this.randomCCPessoa.Size = new System.Drawing.Size(110, 31);
            this.randomCCPessoa.TabIndex = 65;
            this.randomCCPessoa.Text = "RandomCC";
            this.randomCCPessoa.UseVisualStyleBackColor = true;
            this.randomCCPessoa.Click += new System.EventHandler(this.randomCCPessoa_Click_1);
            // 
            // nomePessoaText
            // 
            this.nomePessoaText.Location = new System.Drawing.Point(512, 92);
            this.nomePessoaText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nomePessoaText.Name = "nomePessoaText";
            this.nomePessoaText.Size = new System.Drawing.Size(186, 27);
            this.nomePessoaText.TabIndex = 63;
            // 
            // numCCPessoaText
            // 
            this.numCCPessoaText.Location = new System.Drawing.Point(512, 33);
            this.numCCPessoaText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numCCPessoaText.Name = "numCCPessoaText";
            this.numCCPessoaText.Size = new System.Drawing.Size(186, 27);
            this.numCCPessoaText.TabIndex = 62;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(378, 37);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(58, 20);
            this.label19.TabIndex = 61;
            this.label19.Text = "num_cc";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(345, -55);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(13, 640);
            this.label20.TabIndex = 60;
            this.label20.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n" +
    "|\r\n|\r\n|\r\n|\r\n|\r\n";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(378, 161);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(145, 20);
            this.label22.TabIndex = 58;
            this.label22.Text = "Data de Nascimento";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(378, 96);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(50, 20);
            this.label23.TabIndex = 57;
            this.label23.Text = "Nome";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(-1, 4);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(108, 20);
            this.label24.TabIndex = 56;
            this.label24.Text = "Lista de Pessoa";
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 20;
            this.listBox3.Location = new System.Drawing.Point(-5, 28);
            this.listBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(329, 504);
            this.listBox3.TabIndex = 55;
            // 
            // personagem
            // 
            this.personagem.Controls.Add(this.papelPersonagemCombo);
            this.personagem.Controls.Add(this.nextPersonagemId);
            this.personagem.Controls.Add(this.id_personagemPersonagemText);
            this.personagem.Controls.Add(this.label37);
            this.personagem.Controls.Add(this.name_contentPersonagemLabel);
            this.personagem.Controls.Add(this.id_contentPersonagemCombo);
            this.personagem.Controls.Add(this.label36);
            this.personagem.Controls.Add(this.name_atorPersonagemLabel);
            this.personagem.Controls.Add(this.ator_idPersonagemCombo);
            this.personagem.Controls.Add(this.label34);
            this.personagem.Controls.Add(this.button17);
            this.personagem.Controls.Add(this.button18);
            this.personagem.Controls.Add(this.addPersonagem);
            this.personagem.Controls.Add(this.nomePersonagemText);
            this.personagem.Controls.Add(this.label38);
            this.personagem.Controls.Add(this.label39);
            this.personagem.Controls.Add(this.label40);
            this.personagem.Controls.Add(this.label41);
            this.personagem.Controls.Add(this.listBox5);
            this.personagem.Location = new System.Drawing.Point(4, 29);
            this.personagem.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.personagem.Name = "personagem";
            this.personagem.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.personagem.Size = new System.Drawing.Size(912, 538);
            this.personagem.TabIndex = 5;
            this.personagem.Text = "Personagem";
            this.personagem.UseVisualStyleBackColor = true;
            // 
            // papelPersonagemCombo
            // 
            this.papelPersonagemCombo.FormattingEnabled = true;
            this.papelPersonagemCombo.Items.AddRange(new object[] {
            "Principal",
            "Secundário",
            "Figurante"});
            this.papelPersonagemCombo.Location = new System.Drawing.Point(494, 261);
            this.papelPersonagemCombo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.papelPersonagemCombo.Name = "papelPersonagemCombo";
            this.papelPersonagemCombo.Size = new System.Drawing.Size(186, 28);
            this.papelPersonagemCombo.TabIndex = 104;
            // 
            // nextPersonagemId
            // 
            this.nextPersonagemId.Location = new System.Drawing.Point(710, 28);
            this.nextPersonagemId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nextPersonagemId.Name = "nextPersonagemId";
            this.nextPersonagemId.Size = new System.Drawing.Size(155, 31);
            this.nextPersonagemId.TabIndex = 103;
            this.nextPersonagemId.Text = "nextPersonagemId";
            this.nextPersonagemId.UseVisualStyleBackColor = true;
            this.nextPersonagemId.Click += new System.EventHandler(this.nextPersonagemId_Click);
            // 
            // id_personagemPersonagemText
            // 
            this.id_personagemPersonagemText.Location = new System.Drawing.Point(494, 28);
            this.id_personagemPersonagemText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.id_personagemPersonagemText.Name = "id_personagemPersonagemText";
            this.id_personagemPersonagemText.Size = new System.Drawing.Size(186, 27);
            this.id_personagemPersonagemText.TabIndex = 102;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(378, 33);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(111, 20);
            this.label37.TabIndex = 101;
            this.label37.Text = "Personagem_ID";
            // 
            // name_contentPersonagemLabel
            // 
            this.name_contentPersonagemLabel.AutoSize = true;
            this.name_contentPersonagemLabel.Location = new System.Drawing.Point(702, 87);
            this.name_contentPersonagemLabel.Name = "name_contentPersonagemLabel";
            this.name_contentPersonagemLabel.Size = new System.Drawing.Size(107, 20);
            this.name_contentPersonagemLabel.TabIndex = 100;
            this.name_contentPersonagemLabel.Text = "Content_Name";
            // 
            // id_contentPersonagemCombo
            // 
            this.id_contentPersonagemCombo.FormattingEnabled = true;
            this.id_contentPersonagemCombo.Location = new System.Drawing.Point(494, 83);
            this.id_contentPersonagemCombo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.id_contentPersonagemCombo.Name = "id_contentPersonagemCombo";
            this.id_contentPersonagemCombo.Size = new System.Drawing.Size(186, 28);
            this.id_contentPersonagemCombo.TabIndex = 99;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(378, 87);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(82, 20);
            this.label36.TabIndex = 98;
            this.label36.Text = "Content_ID";
            // 
            // name_atorPersonagemLabel
            // 
            this.name_atorPersonagemLabel.AutoSize = true;
            this.name_atorPersonagemLabel.Location = new System.Drawing.Point(702, 139);
            this.name_atorPersonagemLabel.Name = "name_atorPersonagemLabel";
            this.name_atorPersonagemLabel.Size = new System.Drawing.Size(84, 20);
            this.name_atorPersonagemLabel.TabIndex = 97;
            this.name_atorPersonagemLabel.Text = "Ator_Name";
            // 
            // ator_idPersonagemCombo
            // 
            this.ator_idPersonagemCombo.FormattingEnabled = true;
            this.ator_idPersonagemCombo.Location = new System.Drawing.Point(494, 135);
            this.ator_idPersonagemCombo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ator_idPersonagemCombo.Name = "ator_idPersonagemCombo";
            this.ator_idPersonagemCombo.Size = new System.Drawing.Size(186, 28);
            this.ator_idPersonagemCombo.TabIndex = 96;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(378, 139);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(59, 20);
            this.label34.TabIndex = 95;
            this.label34.Text = "Ator_ID";
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(735, 447);
            this.button17.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(120, 56);
            this.button17.TabIndex = 90;
            this.button17.Text = "Edit";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(560, 447);
            this.button18.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(120, 56);
            this.button18.TabIndex = 89;
            this.button18.Text = "Delete";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // addPersonagem
            // 
            this.addPersonagem.Location = new System.Drawing.Point(395, 447);
            this.addPersonagem.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addPersonagem.Name = "addPersonagem";
            this.addPersonagem.Size = new System.Drawing.Size(120, 56);
            this.addPersonagem.TabIndex = 88;
            this.addPersonagem.Text = "Add";
            this.addPersonagem.UseVisualStyleBackColor = true;
            this.addPersonagem.Click += new System.EventHandler(this.addPersonagem_Click_1);
            // 
            // nomePersonagemText
            // 
            this.nomePersonagemText.Location = new System.Drawing.Point(494, 195);
            this.nomePersonagemText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nomePersonagemText.Name = "nomePersonagemText";
            this.nomePersonagemText.Size = new System.Drawing.Size(186, 27);
            this.nomePersonagemText.TabIndex = 86;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(345, -55);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(13, 640);
            this.label38.TabIndex = 83;
            this.label38.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n" +
    "|\r\n|\r\n|\r\n|\r\n|\r\n";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(378, 261);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(45, 20);
            this.label39.TabIndex = 82;
            this.label39.Text = "Papel";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(378, 199);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(50, 20);
            this.label40.TabIndex = 81;
            this.label40.Text = "Nome";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(-1, 4);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(124, 20);
            this.label41.TabIndex = 80;
            this.label41.Text = "Lista Personagem";
            // 
            // listBox5
            // 
            this.listBox5.FormattingEnabled = true;
            this.listBox5.ItemHeight = 20;
            this.listBox5.Location = new System.Drawing.Point(-5, 28);
            this.listBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(329, 504);
            this.listBox5.TabIndex = 79;
            // 
            // user
            // 
            this.user.Controls.Add(this.passwordUserText);
            this.user.Controls.Add(this.label17);
            this.user.Controls.Add(this.nomeUserText);
            this.user.Controls.Add(this.randomUser);
            this.user.Controls.Add(this.idUserText);
            this.user.Controls.Add(this.label45);
            this.user.Controls.Add(this.label48);
            this.user.Controls.Add(this.button26);
            this.user.Controls.Add(this.button27);
            this.user.Controls.Add(this.addUser);
            this.user.Controls.Add(this.label49);
            this.user.Controls.Add(this.label51);
            this.user.Controls.Add(this.listBox7);
            this.user.Location = new System.Drawing.Point(4, 29);
            this.user.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.user.Name = "user";
            this.user.Size = new System.Drawing.Size(912, 538);
            this.user.TabIndex = 7;
            this.user.Text = "User";
            this.user.UseVisualStyleBackColor = true;
            // 
            // passwordUserText
            // 
            this.passwordUserText.Location = new System.Drawing.Point(498, 136);
            this.passwordUserText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.passwordUserText.Name = "passwordUserText";
            this.passwordUserText.PasswordChar = '*';
            this.passwordUserText.Size = new System.Drawing.Size(186, 27);
            this.passwordUserText.TabIndex = 137;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(383, 140);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 20);
            this.label17.TabIndex = 136;
            this.label17.Text = "Password";
            // 
            // nomeUserText
            // 
            this.nomeUserText.Location = new System.Drawing.Point(498, 83);
            this.nomeUserText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nomeUserText.Name = "nomeUserText";
            this.nomeUserText.Size = new System.Drawing.Size(186, 27);
            this.nomeUserText.TabIndex = 135;
            // 
            // randomUser
            // 
            this.randomUser.Location = new System.Drawing.Point(714, 28);
            this.randomUser.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.randomUser.Name = "randomUser";
            this.randomUser.Size = new System.Drawing.Size(116, 31);
            this.randomUser.TabIndex = 134;
            this.randomUser.Text = "nextUserId";
            this.randomUser.UseVisualStyleBackColor = true;
            this.randomUser.Click += new System.EventHandler(this.randomUser_Click_1);
            // 
            // idUserText
            // 
            this.idUserText.Location = new System.Drawing.Point(498, 28);
            this.idUserText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.idUserText.Name = "idUserText";
            this.idUserText.Size = new System.Drawing.Size(186, 27);
            this.idUserText.TabIndex = 133;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(383, 33);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(59, 20);
            this.label45.TabIndex = 132;
            this.label45.Text = "User_ID";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(383, 87);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(50, 20);
            this.label48.TabIndex = 129;
            this.label48.Text = "Nome";
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(739, 447);
            this.button26.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(120, 56);
            this.button26.TabIndex = 128;
            this.button26.Text = "Edit";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(565, 447);
            this.button27.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(120, 56);
            this.button27.TabIndex = 127;
            this.button27.Text = "Delete";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // addUser
            // 
            this.addUser.Location = new System.Drawing.Point(400, 447);
            this.addUser.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addUser.Name = "addUser";
            this.addUser.Size = new System.Drawing.Size(120, 56);
            this.addUser.TabIndex = 126;
            this.addUser.Text = "Add";
            this.addUser.UseVisualStyleBackColor = true;
            this.addUser.Click += new System.EventHandler(this.addUser_Click_1);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(350, -55);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(13, 640);
            this.label49.TabIndex = 125;
            this.label49.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n" +
    "|\r\n|\r\n|\r\n|\r\n|\r\n";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(3, 4);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(78, 20);
            this.label51.TabIndex = 124;
            this.label51.Text = "Lista Users";
            // 
            // listBox7
            // 
            this.listBox7.FormattingEnabled = true;
            this.listBox7.ItemHeight = 20;
            this.listBox7.Location = new System.Drawing.Point(0, 28);
            this.listBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listBox7.Name = "listBox7";
            this.listBox7.Size = new System.Drawing.Size(329, 504);
            this.listBox7.TabIndex = 123;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(5, -8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "ADMIN";
            // 
            // adminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 600);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "adminForm";
            this.Text = "addForm";
            this.tabControl1.ResumeLayout(false);
            this.estudio.ResumeLayout(false);
            this.estudio.PerformLayout();
            this.conteudo.ResumeLayout(false);
            this.conteudo.PerformLayout();
            this.temporada.ResumeLayout(false);
            this.temporada.PerformLayout();
            this.episodio.ResumeLayout(false);
            this.episodio.PerformLayout();
            this.contentids.ResumeLayout(false);
            this.contentids.PerformLayout();
            this.personagem.ResumeLayout(false);
            this.personagem.PerformLayout();
            this.user.ResumeLayout(false);
            this.user.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TabControl tabControl1;
        private TabPage estudio;
        private TabPage conteudo;
        private TabPage contentids;
        private TabPage episodio;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private ListBox listBox1;
        private Label label1;
        private Button editStudioButton;
        private Button deleteEstudioButton;
        private Button addEstudioButton;
        private Button randomEstudio;
        private TextBox localizacaoEstudioText;
        private TextBox nomeEstudioText;
        private TextBox estudioIDTextBox;
        private Label label6;
        private Label label9;
        private Label Synopsis;
        private Button button5;
        private Button button6;
        private Button addConteudoButton;
        private Button randomConteudoButton;
        private TextBox synopsisConteudoText;
        private TextBox nomeConteudoText;
        private TextBox idConteudoText;
        private Label label7;
        private Label label8;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private ListBox listBox2;
        private TextBox dateConteudoText;
        private TextBox runtimeConteudoText;
        private Label runtimeConteudoLabel;
        private Label dateConteudoLabel;
        private ComboBox tipoConteudoCombo;
        private Button randomidPessoa;
        private TextBox id_atorPessoaText;
        private Label id_atorPessoaLabel;
        private TextBox datePessoaText;
        private TextBox numFIlmesPessoaText;
        private ComboBox tipoPessoaCombo;
        private Label label18;
        private Button button9;
        private Button button10;
        private Button addPessoa;
        private Button randomCCPessoa;
        private TextBox nomePessoaText;
        private TextBox numCCPessoaText;
        private Label label19;
        private Label label20;
        private Label label22;
        private Label label23;
        private Label label24;
        private ListBox listBox3;
        private TabPage personagem;
        private TabPage temporada;
        private Label name_contentEpisodioLabel;
        private ComboBox id_seasonEpisodioCombo;
        private Label label26;
        private TextBox dataEpisodioText;
        private TextBox runtimeEpisodioText;
        private Label label16;
        private Label label25;
        private Button button14;
        private Button button15;
        private Button addEpisodio;
        private TextBox synopsisEpisodioText;
        private TextBox num_episodioEpisodioText;
        private Label label27;
        private Label label28;
        private Label label29;
        private Label label32;
        private ListBox listBox4;
        private Button nextPersonagemId;
        private TextBox id_personagemPersonagemText;
        private Label label37;
        private Label name_contentPersonagemLabel;
        private ComboBox id_contentPersonagemCombo;
        private Label label36;
        private Label name_atorPersonagemLabel;
        private ComboBox ator_idPersonagemCombo;
        private Label label34;
        private Button button17;
        private Button button18;
        private Button addPersonagem;
        private TextBox nomePersonagemText;
        private Label label38;
        private Label label39;
        private Label label40;
        private Label label41;
        private ListBox listBox5;
        private Button randomTemporadaButton;
        private TextBox id_seasonSeasonText;
        private Label label42;
        private Label name_contentSeasonLabel;
        private ComboBox id_contentSeasonCombo;
        private Label label44;
        private Button button22;
        private Button button23;
        private Button addSeasonButton;
        private Label label47;
        private Label label50;
        private ListBox listBox6;
        private TabPage user;
        private TextBox nomeUserText;
        private Button randomUser;
        private TextBox idUserText;
        private Label label45;
        private Label label48;
        private Button button26;
        private Button button27;
        private Button addUser;
        private Label label49;
        private Label label51;
        private ListBox listBox7;
        private TextBox ratingConteudoText;
        private Label ratingConteudoLabel;
        private TextBox num_seasonSeasonText;
        private Label label53;
        private TextBox ratingEpisodioText;
        private Label label31;
        private TextBox dateEstudioText;
        private ComboBox papelPersonagemCombo;
        private Label generoslabel;
        private Label label15;
        private CheckedListBox premiosConteudoCheckBox;
        private CheckedListBox genresConteudoCheckBox;
        private ComboBox nameestudioConteudoCombo;
        private TextBox passwordUserText;
        private Label label17;
        private Button button1;
        private Label Content_id;
        private ComboBox comboBoxContent;
    }
}