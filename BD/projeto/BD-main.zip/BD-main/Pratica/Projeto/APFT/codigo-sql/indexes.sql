CREATE INDEX idx_premio_content_id ON premio (content_id);

CREATE INDEX idx_genero_content_id ON genero (content_id);

CREATE INDEX idx_avalia_content_id ON avalia (content_id);
