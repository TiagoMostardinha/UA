Select * from authors 
