-- SQL script goes here
select pub_name from publishers where pub_name like '%Bo%'