-- SQL script goes here
select au_fname, au_lname, phone 
from authors order by au_fname;

