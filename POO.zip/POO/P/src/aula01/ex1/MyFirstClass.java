package aula01.ex1;

public class MyFirstClass {
    public static void main(String[] args) throws Exception {

        System.out.println("Hello, World!");
    }
}
