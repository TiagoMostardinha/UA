package aula01.ex2;

public class ForSum {

	public static void main(String[] args) throws Exception{
		System.out.println("Hello vs Code");
		int sum = 0;
		for(int i = 1; i <= 100; i++) {
			sum += 1;
		}
		System.out.println(sum);
	}

}
