package aula11.ex2;

public class Vector<T> {

}
