package aula08.ex2
;

public enum VariedadeCarne {
    VACA, PORCO, PERU, FRANGO, OUTRA
}
