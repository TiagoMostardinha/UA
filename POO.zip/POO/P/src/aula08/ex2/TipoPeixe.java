package aula08.ex2;

public enum TipoPeixe {
    CONGELADO, FRESCO
}
