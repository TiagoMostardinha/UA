package aula08.ex1;

public interface KmPercorridosInterface {
    void trajeto(int quilometros);
    int ultimoTrajeto();
    int distanciaTotal();
}
