package aula08.ex1;

public interface Eletrico {
    int autonomia();
    void carregar(int percentagem);
}