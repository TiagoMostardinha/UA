package POO2020;

public interface PVP {
    public double precoVendaAoPublico();
}
