package POO2020;

public enum ClasseEnergetica {
    A,B,C,D,E,F
}
