package package1;

public class exemploclass {

}
