#!/bin/bash
java -ea MainTrain 10 100 1 2 3 R R 4.5 0.1
