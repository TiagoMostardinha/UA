#!/bin/bash
java -ea MainTrain 10 20 2 10 11
