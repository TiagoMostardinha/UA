#!/bin/bash
java -ea MainTrain 10 20 5 7 9
