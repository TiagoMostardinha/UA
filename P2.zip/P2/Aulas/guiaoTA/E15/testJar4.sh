#!/bin/bash

java -ea -jar P1.jar 1 2 out out out
