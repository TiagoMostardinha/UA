
public class HistoryNode {
  String type;
  int numops;
  HistoryNode next;
}

