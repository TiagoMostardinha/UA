#!/bin/bash

java -ea -jar Restaurante.jar food-data01.txt
