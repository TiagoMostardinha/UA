import static java.lang.System.*;
import java.util.Scanner;
import java.io.*;
import pt.ua.p2utils.*;

public class Restaurante {

  public static void main(String[] args) {
    //...

  }

  //...

}

