#!/bin/bash

java -ea -jar Restaurante.jar food-error01.txt
