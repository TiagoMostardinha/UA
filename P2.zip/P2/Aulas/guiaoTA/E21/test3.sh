#!/bin/bash

java -ea Restaurante food-data03.txt
