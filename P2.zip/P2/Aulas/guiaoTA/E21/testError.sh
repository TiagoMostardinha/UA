#!/bin/bash

java -ea Restaurante food-error01.txt
