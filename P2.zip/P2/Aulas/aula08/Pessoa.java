
public class Pessoa implements Comparable<Pessoa>
{
  // Complete a classe.
  //...
}
