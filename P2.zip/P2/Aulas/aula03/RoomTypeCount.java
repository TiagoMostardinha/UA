// Tipo dos elementos do array a devolver por House.getRoomTypeCounts().
public class RoomTypeCount {
  String roomType;
  int count;
}

