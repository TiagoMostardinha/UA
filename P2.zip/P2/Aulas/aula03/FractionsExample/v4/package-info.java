/**
 * Calculadora com fracções - Versão 4:
 * Programa + Módulo.
 * <P>
 * O módulo define um tipo de dados juntamente com
 * as operações associadas a esse tipo.
 */
package v4;

