/**
 * Calculadora com fracções - Versão 2:
 * Programa estruturado com funções adequadas e um novo tipo de dados.
 * <P>
 * Exemplo de uma calculadora simples que trabalha com fracções.
 * Nesta versão, o programa está implementado num único ficheiro:
 * {@link v2.FractionCalculator FractionCalculator.java}.
 */
package v2;

