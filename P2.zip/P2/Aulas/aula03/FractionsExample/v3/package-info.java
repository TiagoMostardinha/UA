/**
 * Calculadora com fracções - Versão 3:
 * Programa + módulo tipo de dados + módulo de funções.
 */
package v3;

