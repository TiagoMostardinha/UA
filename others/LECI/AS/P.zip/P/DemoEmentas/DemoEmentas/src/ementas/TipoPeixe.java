package ementas;

public enum TipoPeixe {
    CONGELADO,
    FRESCO
}
