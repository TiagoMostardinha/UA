import java.util.Scanner;

public class Formula_Resolvente {
	
	public static void main (String[] args) {
		double A,B,C,r1,r2;
		
	}
}

