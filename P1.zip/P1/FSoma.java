import java.util.Scanner;

public class FSoma {
	
	public static void main (String[] args) {
		int a=2, b=3;
		
		int c=sum(a,b);
		System.out.println(c);
		
	}
	
	public static int sum(int a,int b){
		return a+b;
	}
}

