public class DiaAnterior {
	
	public static void main (String[] args) {
		int dia = 1;
		int mes = 1;
		int ano = 2001;
		
	}
}

