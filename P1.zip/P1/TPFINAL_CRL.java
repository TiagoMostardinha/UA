import java.util.*;

//###########
import java.io.*;
//##############

public class TPFINAL_CRL {
	
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int[] funcao={1,5,6,3,6,8,3,10}; //cria array inicial
		int[] newArray = new int[funcao.length]; //cria outro array com a mesma length q array inicial(funcao)
		int max = funcao[0]; //atribui à variavel max o valor de funcao[0]=x
		
		System.out.printf("introduz %d valores: ",funcao.length);
		//forma de ler os n valores pedidos
		for(int i=0;i < funcao.length;i++){
			System.out.printf("funcao[%d]: ",i);
			funcao[i]=sc.nextInt(); //le valores do terminal e preenche o array funcao
		}
		for(int j=0;j<funcao.length;j++){
			if(funcao[j]>max){
				max=funcao[j]; //corre ao longo do array e atualiza o max sempre q encontrar o valor superior ao anterior
			}
		}
		//#1
		int[] derivadas = derivada(funcao);//cria um novo array q vai ser preenchido atraves da funcao derivada
		///////
		//#2
		int numeroMaximos = maximos(derivadas,newArray); //diz o numero de vezes q no array o sinal troca de positivo para negativo na nova array("derivadas")
	}
	
	//#1
	public static int[] derivada(int[] array){
		int[] cenas = new int[array.length-1];// cria um novo array em q este tem uma dimensao mais pequena q o array de entrada
		
		for(int i =0;i<array.length-1;i++){
			cenas[i] = array[i+1]- array[i];//preenche os valores da nova array com a subtracao do proximo com o anterior da array de entrada
		}
		return cenas; //return da nova array criada e preenchida
	}
	
	//#2
	public static int maximos(int[] derivadas,int[] newArray){
		int nrmaximos=0;
		
		for(int i=0;i<derivadas.length;i++){
			if(derivadas[i] < 0 && derivadas[i+1]>=0){//sempre q o proximo é + e o anterior é negativo 
				nrmaximos++;//regista o numero de vezes isto acontece
				newArray[nrmaximos]=(i+1);//preenche a newArray(iniciada e tem a mesma dimensao q o array inicial)em q posicao existe esta troca de sinal(+ para -)
			}
		}
		//###############
		System.out.println(Arrays.toString(newArray));
		//###############
		
		
		return nrmaximos;
	}
	
}

