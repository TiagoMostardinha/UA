import static java.lang.System.*;
import java.util.Arrays;

public class TestFraction1 {
   // Não deve precisar de mudar este programa!
   
   public static void main(String[] args) {
      int test = Integer.parseInt(args[0]);   // Use argument to select test
      
      out.println("Calling constructors...");
      Fraction[] fractions = {
         new Fraction(-2, -1),
         new Fraction(6, 3),
         new Fraction(355, -113),
         new Fraction(-333, 106),
         new Fraction(0),
         new Fraction(-3),
      };

      for (Fraction f: fractions) {
         out.printf("f: %s  f.num(): %d  f.den(): %d\n", f, f.num(), f.den());
      }

      switch (test) {
      case 1:
         out.println("Testing constant...");
         out.printf("ONEHALF: %s\n", Fraction.ONEHALF);
         // A instrução abaixo deve dar um erro de compilação!
         //Fraction.ONEHALF = null;   // This should not be possible!
         break;
      
      case 2:
         out.println("Testing compareTo...");
         for (Fraction f1: fractions) {
            for (Fraction f2: fractions) {
               try {
                  out.printf("(%s) compareTo (%s): ", f1, f2);
                  int d = f1.compareTo(f2);
                  out.printf("%d\n", Integer.signum(d));
               } catch (Throwable e) {
                  out.printf("Caught: %s\n", e);
               }
            }
         }
         break;
         
      case 3:
         out.println("Testing subtract...");
         for (Fraction f1: fractions) {
            for (Fraction f2: fractions) {
               try {
                  out.printf("(%s) subtract (%s): ", f1, f2);
                  Fraction f3 = f1.subtract(f2);
                  out.printf("%s\n", f3);
               } catch (Throwable e) {
                  out.printf("Caught: %s\n", e);
               }
            }
         }
         break;
      
      case 4:
         out.println("Testing parseFraction...");
         String[] strings = {"3/4", "3/-2", "-2/-3", "1/0", "um/2"};
         for (String s: strings) {
            try {
               out.printf("Fraction.parseFraction(\"%s\"): ", s);
               Fraction f3 = Fraction.parseFraction(s);
               out.printf("%s\n", f3);
            } catch (Throwable e) {
               out.printf("Caught: %s\n", e);
            }
         }
         break;
      }

   }
}