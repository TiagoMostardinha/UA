public class Client {
    private String nome;
    private String local;

    public Client(String nome,String local){
        this.nome = nome;
        this.local = local;
    }
    
}
